rootProject.name = "winrate-sw"

package com.swtracker.winrate_sw

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class WinrateSwApplication

fun main(args: Array<String>) {
	runApplication<WinrateSwApplication>(*args)
}

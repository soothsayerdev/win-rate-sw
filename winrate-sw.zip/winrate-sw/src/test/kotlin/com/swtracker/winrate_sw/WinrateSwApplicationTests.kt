package com.swtracker.winrate_sw

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class WinrateSwApplicationTests {

	@Test
	fun contextLoads() {
	}

}
